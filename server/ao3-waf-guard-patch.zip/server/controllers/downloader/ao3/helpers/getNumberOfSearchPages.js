// server/controllers/downloader/ao3/helpers/getNumberOfSearchPages.js
const cheerio = require('cheerio');

module.exports = function getNumberOfSearchPages(html) {
  if (!html || typeof html !== 'string') {
    throw new Error('AO3 HTML not available (possibly WAF/rate-limit).');
  }
  const $ = cheerio.load(html);
  const last = $('.pagination li').last().text().trim();
  const parsed = parseInt(last, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 1;
};
