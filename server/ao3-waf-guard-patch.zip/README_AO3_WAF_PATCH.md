# Copy these two files into your repo at the given paths. Improves WAF detection/headers and adds a guard to avoid cheerio crashing when fetch fails.
